import { request } from "express"

// export const GetSearchHistoryHot() => request.get("/Search/index")
//export const GetSearchTips() => request.get("/Search/helper")