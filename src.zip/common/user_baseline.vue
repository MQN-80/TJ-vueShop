<template lang="html">
  <div>这里暂时还没有内容，快去购物吧</div>

</template>

<script>
  export default {}
</script>

<style lang="less" scoped>
  div {
    padding: 8vw 0;
    text-align: center;
    letter-spacing: .2vw;
    color: rgb(158, 158, 158);
    font-family: Lato, "Microsoft Jhenghei", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
    font-weight: 600;
    font-size: 14px;
  }
</style>